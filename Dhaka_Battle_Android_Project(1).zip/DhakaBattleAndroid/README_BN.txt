DHAKA BATTLE Android Project (Prototype)

এই ZIP ফাইলটি Android Studio project। এটি সরাসরি Android ফোনে ইনস্টল করা যাবে না।
APK তৈরি করতে Android Studio অথবা GitHub Actions-এর মতো অনলাইন build ব্যবস্থা ব্যবহার করতে হবে।

প্রজেক্ট ফোল্ডার: DhakaBattleAndroid
মূল অ্যাপ: app/
গেমের HTML: app/src/main/assets/index.html

নোট: এটি একটি প্রাথমিক single-player 3D driving prototype। Multiplayer, voice chat, parachute drop বা online server এখনো যুক্ত নেই। Three.js CDN ব্যবহারের কারণে গেম চালাতে ইন্টারনেট প্রয়োজন।
